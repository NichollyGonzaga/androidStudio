package br.com.hashtagnoir.core.domain

class CoreDomain {
}
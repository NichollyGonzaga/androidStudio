// FILE: core/domain/src/main/kotlin/br/com/hashtagnoir/core/domain/model/BarcodeScan.kt
package br.com.hashtagnoir.core.domain.model

import java.time.Instant

data class BarcodeScan(
    val value: BarcodeValue,
    val scannedAt: Instant
)
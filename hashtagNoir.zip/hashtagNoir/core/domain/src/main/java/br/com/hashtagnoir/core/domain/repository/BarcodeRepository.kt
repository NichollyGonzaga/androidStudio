// FILE: core/domain/src/main/kotlin/br/com/hashtagnoir/core/domain/repository/BarcodeRepository.kt
package br.com.hashtagnoir.core.domain.repository

import br.com.hashtagnoir.core.domain.model.BarcodeScan
import kotlinx.coroutines.flow.Flow

interface BarcodeRepository {
    suspend fun save(scan: BarcodeScan)
    fun observeHistory(): Flow<List<BarcodeScan>>
    suspend fun syncPending() // placeholder para o futuro (Firebase)
}